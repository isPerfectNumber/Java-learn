package exercise2;

public class IdFormatException extends RuntimeException{
    public IdFormatException() {
    }

    public IdFormatException(String message) {
        super(message);
    }
}
