package exercise2;

public class AgeRangeException extends RuntimeException{
    public AgeRangeException() {
    }

    public AgeRangeException(String message) {
        super(message);
    }
}
