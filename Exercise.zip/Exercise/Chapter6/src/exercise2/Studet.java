package exercise2;

import java.util.Scanner;

public class Studet {
    private String name;
    private String age;
    private String id;

    private Studet() {
    }

    private Studet(String name, String age, String id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static Studet getInstance(Scanner sc) {
        System.out.println("����ѧ������");
        String name = sc.nextLine();
        for (int i = 0; i < name.length(); i++) {
            if ((name.charAt(i) < 'a' || name.charAt(i) > 'z') && (name.charAt(i) < 'A' || name.charAt(i) > 'Z') && name.charAt(i) != ' ') {
                throw new NameFormatException("���ֲ��ɺ�����ĸ��ո�������ַ�");
            }
        }
        System.out.println("����ѧ������");
        String age = sc.nextLine();
        int Age = 0;
        for (int i = 0; i < age.length(); i++) {
            if (age.charAt(i) < '0' || age.charAt(i) > '9') {
                throw new AgeFormatException("�����ʽ����ֻ�ܰ�������");
            }
            Age = (Age * 10) + age.charAt(i) - '0';
        }
        if (Age < 6 || Age > 60) {
            throw new AgeRangeException("ѧ�����䲻����");
        }
        System.out.println("����ѧ��ѧ��");
        String id = sc.nextLine();
        for (int i = 0; i < age.length(); i++) {
            if (id.charAt(i) < '0' || id.charAt(i) > '9') {
                throw new AgeFormatException("ѧ�Ÿ�ʽ����ֻ�ܰ�������");
            }
        }
        return new Studet(name, age, id);
    }
}
