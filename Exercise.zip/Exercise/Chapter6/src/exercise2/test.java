package exercise2;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Studet stu = Studet.getInstance(sc);
        } catch (NameFormatException | AgeFormatException | IdFormatException | AgeRangeException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("end app");
        }
    }
}
