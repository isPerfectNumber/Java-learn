package exercise1;

public class exceptionTest {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        String str = null;
        try {
//            return new RuntimeException();
            throw new IndexOutOfBoundsException();
//            System.out.println(arr[0]);
/*            System.out.println(str.equals(""));*/
        } catch (IndexOutOfBoundsException e) {
            System.out.println("index out of bounds exception");
//            return new IndexOutOfBoundsException();
            throw new IndexOutOfBoundsException();
//            System.out.println(arr[0]);
        } /*catch (NullPointerException e) {
            System.out.println("null pointer exception");
        }*/
        finally {
            System.out.println("finally block");
//            return new RuntimeException();
            throw new RuntimeException();
//            System.out.println(arr[0]);
        }
    }
}
