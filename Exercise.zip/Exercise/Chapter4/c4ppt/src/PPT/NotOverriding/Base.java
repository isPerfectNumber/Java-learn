package PPT.NotOverriding;

public class Base {
    private int i = 100;

    public void increase() {
        this.i++;
    }

    public int getI() {
        return this.i;
    }
}
