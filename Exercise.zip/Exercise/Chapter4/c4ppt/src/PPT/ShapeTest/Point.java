package PPT.ShapeTest;

public class Point {
    private double x;
    private double y;

    public Point() {
    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    double distance(Point p) {
        double delta_x = Math.abs(this.x - p.x);
        double delta_y = Math.abs(this.y - p.y);
        return Math.sqrt(Math.pow(delta_x, 2) + Math.pow(delta_y, 2));
    }
}
