package PPT.ShapeTest;

public class Rectangle {
    private double width;
    private double height;

    private Point p = new Point();

    public Rectangle() {
    }

    public Rectangle(double width, double height, Point p) {
        this.width = width;
        this.height = height;
        this.p.setX(p.getX());
        this.p.setY(p.getY());
    }

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    double getArea() {
        return width * height;
    }

    double getPerimeter() {
        return 2 * (width + height);
    }
}
