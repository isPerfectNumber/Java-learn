package PPT.OrderOflnit;

public class OrderOflnit {
    public static void main(String[] args) {
        House h = new House();
        h.f();
    }
}
