package PPT.OrderOflnit;

public class Window {
    Window(int m){
        System.out.println("window" + m);
    }
}
