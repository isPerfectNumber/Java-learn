package PPT;

public class PassTest_2 {
    public void changeStr(String value) {
        value = new String("different");
    }

    public static void main(String[] args) {
        String str;
        PassTest_2 pt = new PassTest_2();

        str = new String("Hello");
        pt.changeStr(str);
        System.out.println("Str value is: " + str);
    }
}
