package PPT;

public class PassTest {
    public void changeInt(int value) {
        value = 55;
    }

    public static void main(String[] args) {
        int val;
        PassTest pt = new PassTest();

        val = 11;
        pt.changeInt(val);
        System.out.println("Int value is: " + val);
    }
}
