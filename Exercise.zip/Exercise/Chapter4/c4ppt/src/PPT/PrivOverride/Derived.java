package PPT.PrivOverride;

public class Derived extends PrivOverride {
    public int a;

    public void f() {
        System.out.println("public f()");
    }
}
