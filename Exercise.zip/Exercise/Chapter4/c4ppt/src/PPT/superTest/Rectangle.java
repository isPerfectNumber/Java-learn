package PPT.superTest;

public class Rectangle extends Shape {
    public void draw() {
        System.out.println("Draw Rectangle");
    }

    public void newDraw() {
        draw();
        super.draw();
    }
}
