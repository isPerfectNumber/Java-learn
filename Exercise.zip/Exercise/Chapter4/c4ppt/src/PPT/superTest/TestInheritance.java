package PPT.superTest;

public class TestInheritance {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle();
        rect.newDraw();
    }
}
