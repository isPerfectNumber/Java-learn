package PPT.superTest;

public class Shape {
    public void draw() {
        System.out.println("Draw shape");
    }
}
