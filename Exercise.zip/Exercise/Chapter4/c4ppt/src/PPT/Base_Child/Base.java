package PPT.Base_Child;

public class Base {
    int i = 0;

    {
        System.out.println("In Base Initial block: i = " + i++);//j++;
    }

    Base() {
        System.out.println("In Base constructor: i = " + i++);//Base(0);
    }

    Base(int j) {
        this.j = j;
    }

    int j = 0;

    public static void main(String[] args) {
        Child c = new Child();
    }
}
