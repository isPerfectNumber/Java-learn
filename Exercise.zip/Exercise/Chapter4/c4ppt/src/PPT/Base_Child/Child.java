package PPT.Base_Child;

public class Child extends Base {
    int i = 0;

    {
        System.out.println("In Base Initial block: i = " + i++);//j++;
    }

    Child() {
        System.out.println("In Child constructor: i = " + i);//super();
    }
}
