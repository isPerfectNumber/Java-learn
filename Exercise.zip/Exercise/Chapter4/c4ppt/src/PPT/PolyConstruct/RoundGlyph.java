package PPT.PolyConstruct;

public class RoundGlyph extends Glyph {
    private int radius = 1;

    RoundGlyph(int r) {
        radius = r;
        System.out.println("RG.RoundGlyph(), radius = " + radius);
    }

    void draw() {
        System.out.println("RG.draw(), radius = " + radius);
    }

}
