package PPT.PolyConstruct;

public class PolyConstruct {
    public static void main(String[] args) {
        new RoundGlyph(5);
    }
}
