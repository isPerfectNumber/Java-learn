package PPT;

public class PassTest_3 {
    float ptValue;

    public void changeObjValue(PassTest_3 ref) {
        ref.ptValue = 99.0f;
    }

    public static void main(String[] args) {
        PassTest_3 pt = new PassTest_3();
        pt.ptValue = 101.0f;
        pt.changeObjValue(pt);
        System.out.println("Pt value is: " + pt.ptValue);
    }
}
