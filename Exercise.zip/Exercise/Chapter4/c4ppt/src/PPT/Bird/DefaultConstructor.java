package PPT.Bird;

public class DefaultConstructor {
    public static void main(String[] args) {
        Bird nc = new Bird();
        System.out.println(nc.i);
    }
}
