package PPT.Bird;

public class Bird {
    int i;

/*    public Bird(int j) {
        i = j;
    }*/
}
