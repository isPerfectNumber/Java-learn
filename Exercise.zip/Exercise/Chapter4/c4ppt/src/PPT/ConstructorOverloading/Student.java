package PPT.ConstructorOverloading;

public class Student {
    private String name;
    private String id;

    public Student(String nm, String id) {
        this.name = nm;
        this.id = id;
    }

    public Student(String nm) {
        this(nm, "00000000");
    }

    public Student() {
        this("Unknown");
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }
}
