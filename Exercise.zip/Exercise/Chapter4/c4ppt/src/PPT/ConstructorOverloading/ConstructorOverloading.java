package PPT.ConstructorOverloading;

public class ConstructorOverloading {
    public static void main(String[] args) {
        Student stu = new Student();
        System.out.println(stu.getName() + "," + stu.getId());
    }
}
