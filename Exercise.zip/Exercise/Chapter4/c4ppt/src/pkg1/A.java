package pkg1;

public class A {
    public A(){
        System.out.println("A's constructor");
    }
    void func(){
        System.out.println("A's method");
    }//func()Ϊ��Ȩ��
}

class B {//BΪ��Ȩ��
    public B(){
        System.out.println("B's constructor");
    }
}
