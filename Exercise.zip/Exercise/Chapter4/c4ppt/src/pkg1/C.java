package pkg1;

public class C {
    protected void func(){
        System.out.println("Protected method of C");
    }
}
