package pkg2;

public class C {
    private void func1(){
        System.out.println("C's method 1");
    }
    void func2(){
        System.out.println("C's method 2");
        this.func1();//ͬһ�����п��Ե���func1()
    }
}
