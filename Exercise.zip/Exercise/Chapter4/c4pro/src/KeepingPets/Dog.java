package KeepingPets;

public class Dog extends Pet {
    private String name;
    private int favouriteIndex;
    private int AmountNeedEat;

    public Dog(String name, int favouriteIndex, int amountNeedEat) {
        super(name, favouriteIndex, amountNeedEat);
        this.name = name;
        this.favouriteIndex = favouriteIndex;
        this.AmountNeedEat = amountNeedEat;
    }

    public String doSomething() {
        if (!this.hungry()) return "Let's go outside for a wallow.";
        else return "still want to eat more food.";
    }
}
