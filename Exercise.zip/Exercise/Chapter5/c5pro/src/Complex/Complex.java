package Complex;

import java.util.Objects;

public class Complex extends java.lang.Number implements Comparable<Complex> {
    private double real, img;

    public Complex() {
    }

    public Complex(double real, double img) {
        this.real = real;
        this.img = img;
    }

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public double getImg() {
        return img;
    }

    public void setImg(double img) {
        this.img = img;
    }

    public boolean equals(Complex c) {
        if (this.img == 0 && c.img == 0) {
            return this.real == c.real;
        } else return false;
    }

    public boolean equals(Complex a, Complex b) {
        if (a.img == 0 && b.img == 0) {
            return a.real == b.real;
        } else return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(real, img);
    }

    @Override
    public String toString() {
        if (img >= 0) return real + "+" + img + "i";
        else return real + "-" + Math.abs(img) + "i";
    }

    //�ӷ�
    public void add(Complex a) {
        this.real += a.real;
        this.img += a.img;
    }

    public void add(double a) {
        this.real += a;
    }

    //����
    public void dec(Complex a) {
        this.real -= a.real;
        this.img -= a.img;
    }

    public void dec(double a) {
        this.real -= a;
    }

    //�˷�
    public void mul(Complex a) {
        double t = this.real;
        this.real = t * a.real - this.img * a.img;
        this.img = t * a.img + this.img * a.real;
    }

    public void mul(double a) {
        this.real *= a;
        this.img *= a;
    }

    //����
    public void div(Complex a) {
        double t = this.real;
        this.real = (t * a.real + this.img * a.img) / (a.real * a.real + a.img * a.img);
        this.img = (this.img * a.real - t * a.img) / (a.real * a.real + a.img * a.img);
    }

    public void div(double a) {
        this.real /= a;
        this.img /= a;
    }

    public int compareTo(Complex c) {
        if (this.equals(c)) return 1;
        else return 0;
    }

    public int intValue() {
        return (int) real;
    }

    public long longValue() {
        return (long) real;
    }

    public float floatValue() {
        return (float) real;
    }

    public double doubleValue() {
        return real;
    }
}
