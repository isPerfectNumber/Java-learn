package Complex;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("��ӭʹ�ø���������");
        loop:
        while (true) {
            System.out.println("ѡ����");
            System.out.println("1.�ӷ�");
            System.out.println("2.����");
            System.out.println("3.�˷�");
            System.out.println("4.����");
            System.out.println("5.�˷�");
            System.out.println("0.�˳�");
            System.out.println("ѡ����:");
            int op = sc.nextInt();
            switch (op) {
                case 0:
                    break loop;
                case 1:
                    Complex[] cs1 = initComplex(sc);
                    cs1[0].add(cs1[1]);
                    System.out.println(cs1[0]);
                    break;
                case 2:
                    Complex[] cs2 = initComplex(sc);
                    cs2[0].dec(cs2[1]);
                    System.out.println(cs2[0]);
                    break;
                case 3:
                    Complex[] cs3 = initComplex(sc);
                    cs3[0].mul(cs3[1]);
                    System.out.println(cs3[0]);
                    break;
                case 4:
                    Complex[] cs4 = initComplex(sc);
                    cs4[0].div(cs4[1]);
                    System.out.println(cs4[0]);
                    break;
                case 5:
                    System.out.println("����һ������");
                    sc.nextLine();
                    String s = sc.nextLine();
                    Complex c = valueOf(s);
                    Complex ans = new Complex(c.getReal(), c.getImg());
                    System.out.println("������(������)");
                    int index = sc.nextInt();
                    if (index > 0) {
                        for (int i = 0; i < index; i++) {
                            ans.mul(c);
                        }
                        ans.div(c);
                        System.out.println(ans);
                    } else System.out.println("�������");
                    break;
                default:
                    break;
            }
        }
    }

    private static Complex[] initComplex(Scanner sc) {
//        System.out.println("�밴�ա�a+bi���ĸ�ʽ����");
        Complex[] cs = new Complex[2];
        System.out.println("�����һ������:");
        sc.nextLine();
        String s1 = sc.nextLine();
        cs[0] = valueOf(s1);
        System.out.println("����ڶ�������:");
        String s2 = sc.nextLine();
        cs[1] = valueOf(s2);
        return cs;
    }

    public static Complex valueOf(String str) {
        double real = 0;
        double img = 0;
        if (str.contains("i")) {
            if (str.contains("+") || str.contains("-")) {
                boolean flag = false;                       // �ж�ʵ�����鲿����
                boolean flag2 = false;                      // �ж�������С������
                real = 0;
                img = 0;
                int cnt = 0;
                for (int i = 0; i < str.length(); i++) {
                    boolean b1 = str.charAt(i) == '+' || str.charAt(i) == '-';
                    boolean b2 = str.charAt(i) >= '0' && str.charAt(i) <= '9';
                    boolean b3 = str.charAt(i) == '.';
                    boolean b4 = str.charAt(i) == 'i';
                    if (b1 && str.charAt(i + 1) == 'i') {   //�ر����
                        img = 1;
                        break;
                    }
                    if (!b1 && !b2 && !b3 && !b4) {         // �﷨����
                        System.out.println("����������Զ���ʼ��Ϊ0+0i");
                        return new Complex(0, 0);
                    }
                    if (b1) {                               // ʵ�����鲿�ֽ�
                        flag = true;
                        flag2 = false;
                        cnt = 0;
                        continue;
                    }
                    if (b2 || b3) {                         //���ֲ���
                        if (flag) {                             // �鲿
                            if (b3) {                               // С����
                                flag2 = true;
                                continue;
                            }
                            if (!flag2) {                           // ��������
                                int num = str.charAt(i) - '0';
                                img = (10 * img) + num;
                            } else {                                // С������
                                cnt++;
                                int num = str.charAt(i) - '0';
                                img += num * Math.pow(10, -cnt);
                            }
                        } else {                                // ʵ��
                            if (b3) {                               //С����
                                flag2 = true;
                                continue;
                            }
                            if (!flag2) {                           // ��������
                                int num = str.charAt(i) - '0';
                                real = (10 * real) + num;
                            } else {                                // С������
                                cnt++;
                                int num = str.charAt(i) - '0';
                                real += num * Math.pow(10, -cnt);
                            }
                        }
                    }
                }// for
            }// if (str.contains("+") || str.contains("-"))
            else {
                if (str.equals("i")) return new Complex(0, 1);
                boolean flag = false;
                int cnt = 0;
                for (int i = 0; i < str.length(); i++) {
                    if (str.charAt(i) == '.') {
                        flag = true;
                        continue;
                    }
                    if (str.charAt(i) == 'i') break;
                    if (!flag) {
                        int num = str.charAt(i) - '0';
                        img = (10 * img) + num;
                    } else {
                        cnt++;
                        int num = str.charAt(i) - '0';
                        img += num * Math.pow(10, -cnt);
                    }
                }
            }
        } else {
            boolean flag = false;
            int cnt = 0;
            for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) == '.') {
                    flag = true;
                    continue;
                }
                if (!flag) {
                    int num = str.charAt(i) - '0';
                    real = (10 * real) + num;
                } else {
                    cnt++;
                    int num = str.charAt(i) - '0';
                    real += num * Math.pow(10, -cnt);
                }
            }
        }
        return new Complex(real, img);
    }
}
