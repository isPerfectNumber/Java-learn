package LibraryManage;

import java.util.ArrayList;
import java.util.Objects;

class Book {
    private String name;
    private ArrayList<String> author = new ArrayList<>();
    private String pressingHouse;

    public Book() {
    }

    public Book(String name, ArrayList<String> author, String pressingHouse, int number) {
        this.name = name;
        this.author = author;
        this.pressingHouse = pressingHouse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getAuthor() {
        return author;
    }

    public void setAuthor(ArrayList<String> author) {
        this.author = author;
    }

    public String getPressingHouse() {
        return pressingHouse;
    }

    public void setPressingHouse(String pressingHouse) {
        this.pressingHouse = pressingHouse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(name, book.name) && Objects.equals(author, book.author) && Objects.equals(pressingHouse, book.pressingHouse);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, author, pressingHouse);
    }
}
