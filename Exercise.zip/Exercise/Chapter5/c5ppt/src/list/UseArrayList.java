package list;

import java.util.ArrayList;
import java.util.List;

public class UseArrayList {
    public static void main(String[] args) {
        List<String> scores = new ArrayList<String>();
        scores.add("86");
        scores.add("98");
        scores.add(1, "99");
        for (int i = 0; i < scores.size(); i++) {
            System.out.print(scores.get(i) + " ");
        }
        scores.set(1, "77");
        scores.remove(0);
//        boolean flag = scores.remove("98");
//        System.out.println(flag);
        System.out.println("\n�޸Ĳ�ɾ��֮��");
        for (int i = 0; i < scores.size(); i++) {
            System.out.print(scores.get(i) + " ");
        }
        System.out.println("\n���ַ������\n" + scores.toString());
    }
}
