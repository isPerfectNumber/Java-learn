package calendar;

public class demo2 {

    public static int year;
    public static int month;
    public static int day;

    public static void main(String[] args) {
        for (int i = 1; i < 1001; i++) {
            year = i;
            if (i > 1) {
                int days1 = DaysPassed(i, 12, 31);
                int days2 = DaysPassed(i - 1, 12, 31);
                if (days1 - days2 == 366) {
                    System.out.println(i + ":   " + (days1 - days2));
                } else {
                    System.out.println(i + ":" + (days1 - days2));
                }
            } else {
                System.out.println(i + ":" + DaysPassed(i, 12, 31));
            }
        }
    }

    public static int DaysPassed(int year, int month, int day) {
        {
            int days = 0;
            if (year > 1) {
                for (int i = 1; i < year; i++) {
                    days += isLeap(i) ? 366 : 365;
                }
            }
            if (month > 1) {
                for (int i = 1; i < month; i++) {
                    days += DaysInMonth(year, i);
                }
            }
            days += day;
            return days;
        }
    }

    public static boolean isLeap(int year) {
        return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0);
        //�������������true
    }

    //���ĳ���·��������
    private static int DaysInMonth(int year, int month) {
        return switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 -> 31;
            case 2 -> isLeap(year) ? 29 : 28;
            default -> 30;
        };
    }
}
