package calendar;

import java.util.Scanner;

public class calendar {
    //将用户输入的年月日作为静态成员变量
    public static int year;
    public static int month;
    public static int day;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        loop:
        while (true) {
            {
                System.out.println("请选择功能(1 or 2):");
                System.out.println("1.输入年份，输出该年日历");
                System.out.println("2.输入日期，获得该天星期");
                System.out.println("0.退出该程序");
            }   //初始界面
            int cmd = sc.nextInt();

            switch (cmd) {
                case 0:
                    break loop;
                case 1:
                    Option1();
                    break;
                case 2:
                    Option2();
                    break;
            }
        }
        System.out.println("感谢使用。");
    }

    //功能1的主体
    public static void Option1() {
        Scanner sc = new Scanner(System.in);
        setYear(sc);
        System.out.println("该年日历如下");
        for (int i = 1; i <= 12; i++) {
            printCalendar(year, i);
            System.out.println();
        }
    }

    //功能2的主体
    public static void Option2() {
        Scanner sc = new Scanner(System.in);
        setYear(sc);
        setMonth(sc);
        setDay(sc);
        int days = DaysPassed(year, month, day);
        getDay(days);
    }

    private static void setDay(Scanner sc) {//输入日期管理
        System.out.println("请输入日期:");
        //对输入的日期甄别，确保传入函数的参数正确
        while (true) {
            day = sc.nextInt();
            if (day > DaysInMonth(year, month)) {
                System.out.println("当前输入日期超出该月天数，请重新输入！");
            } else if (day < 1) {
                System.out.println("日期输入错误，请重新输入！");
            } else break;
        }
    }

    private static void setMonth(Scanner sc) {//输入月份管理
        System.out.println("请输入月份:");
        //对输入的月份甄别，对错误的月份做出提示并请用户重新输入
        while (true) {
            month = sc.nextInt();
            if (month < 1 || month > 12) {
                System.out.println("月份输入错误，请重新输入！");
            } else break;
        }
    }

    private static void setYear(Scanner sc) {//输入年份管理
        System.out.println("请输入年份:(公元元年及以后)");
        //对输入的年份进行甄别，若小于1则提示错误后循环
        while (true) {
            year = sc.nextInt();
            if (year <= 0) {
                System.out.println("请输入公元元年及以后的年份！");
            } else break;
        }
    }

    //判断该年是否为闰年
    public static boolean isLeap(int year) {
        return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0);
        //若是闰年则输出true
    }

    //获得某个月份里的天数
    private static int DaysInMonth(int year, int month) {
        return switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 -> 31;
            case 2 -> isLeap(year) ? 29 : 28;
            default -> 30;
        };
    }

    //以1年1月1日(星期一)为时间原点，计算经过的天数
    public static int DaysPassed(int year, int month, int day) {
        {
            int days = 0;
            if (year > 1) {
                for (int i = 1; i < year; i++) {
                    days += isLeap(i) ? 366 : 365;
                }
            }
            if (month > 1) {
                for (int i = 1; i < month; i++) {
                    days += DaysInMonth(year, i);
                }
            }
            days += day;
            return days;
        }
    }

    //获得某日的星期并打印输出
    public static void getDay(int days) {   //传入DaysPassed的结果
        String[] dayName = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        int Day = days % 7;
        System.out.println("这天是" + dayName[Day] + "。");
    }

    //打印某年某月的日历
    public static void printCalendar(int year, int month) {
        String[] monthName = {"0", "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"};
        System.out.println(monthName[month]);

        System.out.println("SUN MON TUE WED THU FRI SAT");
        int spaceCnt = DaysPassed(year, month, 1) % 7;
        if (spaceCnt > 0) {
            for (int i = 0; i < spaceCnt; i++) {
                System.out.print("\t");
            }
        }
        for (int i = 1; i <= DaysInMonth(year, month); i++) {
            System.out.printf("%2d\t", i);
            if (DaysPassed(year, month, i) % 7 == 6) System.out.println();
        }
    }
}
