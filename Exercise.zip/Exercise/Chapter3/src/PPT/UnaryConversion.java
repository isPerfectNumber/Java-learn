package PPT;

public class UnaryConversion {
    public static void main(String[] args) {
        byte b = 2;
        char c = '\u1234';
        int x = 8, y = 3;
//        byte b2 = -b;       //intֵ����ֱ�Ӹ���byte���ͱ���b2
//        char c2 = +c;       //intֵ����ֱ�Ӹ���char���ͱ���c2
        byte b3 = --b;
//        short b4 = -b;
        char c3 = ++c;
//        char c4 = +c;
        System.out.println((-b)+";"+(+c));
        int i = ~b;         //byteת����int
        System.out.println(Integer.toHexString(i)); //fffffffd
        System.out.println(x/y);                    //2
        System.out.println(x/(float)y);             //2.6666667
        System.out.println(x/(double)y);            //2.6666666666666665
    }
}
