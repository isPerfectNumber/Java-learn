package PPT;

public class CharConst {
    public static void main(String[] args) {
        char c1 = 'Q';          //Q
        char c2 = '\u0051';     //Q
        char c3 = 0x0051 + 1;   //R
        char c4 = 51;           //3
        System.out.println(c1 + ";" + c2 + ";" + c3 + ";" + c4 + ";" + '\121');
    }
}
