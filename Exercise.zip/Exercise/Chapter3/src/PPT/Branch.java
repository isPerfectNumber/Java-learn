package PPT;

public class Branch {
    public static void main(String[] args) {
        int x = 3;
//        if (x) {
//            System.out.println("tag 1");
//        }
        if (x != 0) {
            System.out.println("tag 2");
        }
    }
}
