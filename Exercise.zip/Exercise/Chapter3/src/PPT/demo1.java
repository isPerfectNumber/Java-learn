package PPT;

public class demo1 {
    public static void main(String[] args) {
/*        float f;
        boolean b = (f = 20);*/
    }
}
