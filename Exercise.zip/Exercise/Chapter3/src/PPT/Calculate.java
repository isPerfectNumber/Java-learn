package PPT;

public class Calculate {
    public static void main(String[] args) {
        int a = 1;
        double d = 1.0;
        a = 46 / 9;
        System.out.println("a = "+ a);
        a = 46 % 9 + 4 * 4 - 2;
        System.out.println("a = "+ a);
        a = 45 + 43 % 5 * (23 * 3 % 2);
        System.out.println("a = "+ a);
        d = 4 + d * d + 4;
        System.out.println("d = "+ d);
        a = 1;
        d = 1.0;
        d += 1.5 * 3 + (++a);
        System.out.println("d = " + d + "  a = " + a);
        a = 1;
        d = 1.0;
        d -= 1.5 * 3 + a++;
        System.out.println("d = " + d + "  a = " + a);
    }
}
