package PPT;

class Value {
    int i;

    public boolean equals(Value v) {
        return (this.i == v.i) ? true : false;
    }
}
