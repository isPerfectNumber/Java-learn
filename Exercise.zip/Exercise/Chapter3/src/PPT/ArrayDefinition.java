package PPT;

public class ArrayDefinition {
    public static void main(String[] args) {
//        int i = new int (30);
//        double d[] = new double[30];
//        Integer[] r = new Integer(1. .30);
//        int i1[] = (3, 4, 3, 2);
//        float f[] = {2.3, 4.5, 5.6};
//        char[] c = new char();
//        Integer[][] r1 = new Integer[2];
    }
}
