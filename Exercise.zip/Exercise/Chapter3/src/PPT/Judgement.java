package PPT;

public class Judgement {
    public static void main(String[] args) {
        System.out.println(0.0 == -0.0);                //true
        System.out.println(0.0 > -0.0);                 //false
        System.out.println(1.0 < Double.NaN);           //false
        System.out.println(1.0 > Double.NaN);           //false
        System.out.println(1.0 == Double.NaN);          //false
        System.out.println(1.0 != Double.NaN);          //true
        System.out.println(Double.NaN == Double.NaN);   //false
        System.out.println(0.0 / 0.0);                  //NaN
        System.out.println(1.0 / 0.0);                  //Infinity
        System.out.println(1.0 / -0.0);                 //-Infinity
        System.out.println(1.0 * 0.0);
        System.out.println(1.0 * -0.0);
    }
}
