package PPT;

public class ArrayLength {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3, 4, 5}, {1, 2, 3}};
        System.out.println(a.length + ";" + a[0].length + ";" + a[1].length);
    }
}
