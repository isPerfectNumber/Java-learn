package PPT;

public class Expression {
    public static void main(String[] args) {
        int x = 1;
        int y = 2;
//        System.out.println(x > y > 0);
//        System.out.println(x = y && y);
//        System.out.println(x /= y);
//        System.out.println(x or y);
//        System.out.println(x and y);
//        System.out.println((x != 0) || (x = 0));

        int a = 1, b = 1, c = 1;
        a = b += c = 5;
        System.out.println("a = " + a);     //a = 6
        System.out.println("b = " + b);     //b = 6
        System.out.println("c = " + c);     //c = 5
    }
}
