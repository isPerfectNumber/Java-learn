package PPT;

public class Loop {
    public static void main(String[] args) {
        double item = 1, sum = 0;
        int cnt = 0;
        while (item != 0) {
            sum += item;
            item -= 0.2;
            cnt++;
        }
        System.out.println("item = " + item);
        System.out.println("sum = " + sum);
        System.out.println("cnt = " + cnt);
    }
}
