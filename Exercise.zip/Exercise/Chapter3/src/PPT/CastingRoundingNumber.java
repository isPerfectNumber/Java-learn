package PPT;

public class CastingRoundingNumber {
    public static void main(String[] args) {
        float f = 12.5f;
        double d = 3.1415;
        int i = (int) f;
        System.out.println(f);
        System.out.println(i);
        i = (int) d;
        System.out.println(d);
        System.out.println(i);

//        boolean b = true;
//        int i1 = (int)b;
//        int i2 = 1;
//        boolean b1 = (boolean) i;
    }
}
