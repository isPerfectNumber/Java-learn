package StringJoinerDemo;

import java.util.StringJoiner;

public class demo2 {
    public static void main(String[] args) {
        //1.��������
        StringJoiner sj = new StringJoiner(", ", "[", "]");
        //2.����Ԫ��
        sj.add("aaa").add("bbb").add("ccc");

        int len = sj.length();
        System.out.println(len);//15

        //3.��ӡ
        System.out.println(sj);//[aaa, bbb, ccc]

        String str = sj.toString();
        System.out.println(str);//[aaa, bbb, ccc]
    }
}
