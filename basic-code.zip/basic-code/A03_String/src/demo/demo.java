package demo;

import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        //sc.next()�����ո�ֹͣ¼��
        int cnt = 0;
        for (int i = str.length() - 1; i >= 0; i--) {
            if (str.charAt(i) != ' ') {
                cnt++;
            } else {
                break;
            }
        }
        System.out.println(cnt);
    }
}
