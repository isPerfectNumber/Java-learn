package StrProduct;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        //���ַ�����ʽ���������Ǹ������������������ĳ˻����������ַ�����ʽ��ʾ
        Scanner sc = new Scanner(System.in);
        String[] str = new String[2];
        for (int i = 0; i < 2; ) {
            System.out.println("�������" + (i + 1) + "���Ǹ�����");
            str[i] = sc.next();
            boolean flag = check(str[i]);
            if (!flag) {
                System.out.println("���ݷǷ������������룡");
            } else {
                i++;
            }
        }

        int num1 = StrToNum(str[0]);
        int num2 = StrToNum(str[1]);
//        System.out.println(num1);
//        System.out.println(num2);
        int prod = num1 * num2;
        String result = NumToStr(prod);
        System.out.println(result);

    }

    public static boolean check(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) < '0' || str.charAt(i) > '9') {
                return false;
            }
        }
        return true;
    }

    public static int StrToNum(String str) {
        int num = 0;
        for (int i = str.length() - 1; i >= 0; i--) {
            int unit = str.charAt(i) - '0';
            num += unit * (int) Math.pow(10, str.length() - i - 1);
        }
        return num;
    }

    public static String NumToStr(int num) {
        StringBuilder str = new StringBuilder();
        while (num > 0) {
            str.append(num % 10);
            num /= 10;
        }
        str = str.reverse();
        String result = str.toString();
        return result;
    }
}
