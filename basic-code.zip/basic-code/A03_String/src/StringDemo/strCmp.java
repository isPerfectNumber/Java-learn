package StringDemo;

public class strCmp {
    public static void main(String[] args) {
        //1.���������ַ�������
        String s1 = new String("abc");
        String s2 = "abc";
        String s3 = "Abc";
        //2."=="�űȽ�
        System.out.println(s1 == s2);   //false
        //3.�Ƚ��ַ��������е�����
        boolean result1 = s1.equals(s2);
        boolean result2 = s1.equals(s3);
        System.out.println(result1);    //true
        System.out.println(result2);    //false

        boolean result3 = s1.equalsIgnoreCase(s2);
        boolean result4 = s1.equalsIgnoreCase(s3);
        System.out.println(result3);    //true
        System.out.println(result4);    //true
    }
}
