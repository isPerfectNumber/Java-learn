package verificationCode_plus;

import java.util.Random;

public class test {
    public static void main(String[] args) {
        //����5λ��֤�룬4λ��ĸ1λ���֣������ֳ��������λ�ã�
        Random r = new Random();

        char[] arr = new char[52];
        for (int i = 0; i < arr.length; i++) {
            if (i <= 25) {
                arr[i] = (char) (97 + i);
            } else {
                arr[i] = (char) (65 + i - 26);
            }
        }

        char[] code = new char[5];
        for (int i = 0; i < 4; i++) {
            int index = r.nextInt(arr.length);
            code[i] = arr[index];
        }
        code[4] = (char) r.nextInt('0', '9' + 1);

        int location = r.nextInt(4);
        char temp;
        temp = code[4];
        code[4] = code[location];
        code[location] = temp;

        String result = new String(code);
        System.out.println(result);
    }
}
