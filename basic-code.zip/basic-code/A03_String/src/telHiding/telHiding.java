package telHiding;

import java.util.Scanner;

public class telHiding {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String phoneNumber = "";
        while (true) {
            System.out.println("�������ֻ�����");//111-1111-1111
            phoneNumber = sc.next();
            if (phoneNumber.length() != 11) {
                System.out.println("�����ʽ��������������");
            } else {
                break;
            }
        }

        String start = phoneNumber.substring(0, 3);
        String end = phoneNumber.substring(7);
        String result = start + "****" + end;

        System.out.println(result);
    }
}
