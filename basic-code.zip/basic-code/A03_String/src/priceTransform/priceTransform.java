package priceTransform;

import java.util.Scanner;

public class priceTransform {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = null;
        while (true) {
            System.out.println("����������");
            num = sc.next();
            if (num.length() > 7) {
                System.out.println("�����Ч������������");
            } else {
                break;
            }
        }
        String result = "";
        String[] chinese = {"��", "Ҽ", "��", "��", "��", "��", "½", "��", "��", "��"};

        for (int i = 0; i < 7 - num.length(); i++) {
            result = result + "��";
        }
        for (int i = 0; i < num.length(); i++) {
            char ch = num.charAt(i);
            result = result + chinese[ch - '0'];
        }

        for (int i = 0; i < result.length(); i++) {
            System.out.print(result.charAt(i));
            if (i == 0 || i == 4) {
                System.out.print("��");
            } else if (i == 1 || i == 5) {
                System.out.print("ʰ");
            } else if (i == 2) {
                System.out.print("��");
            } else if (i == 3) {
                System.out.print("Ǫ");
            }
        }
    }
}
