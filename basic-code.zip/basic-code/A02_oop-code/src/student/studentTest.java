package student;

public class studentTest {
    public static void main(String[] args) {
        //����ѧ���Ķ���
        student stu1 = new student();
        //��ֵ
        stu1.setName("����");
        stu1.setAge(18);
        stu1.setGender("��");
        System.out.println(stu1.getName());
        System.out.println(stu1.getAge());
        System.out.println(stu1.getGender());

        stu1.study();
        stu1.sleep();

        System.out.println("***************************");
        student stu2 = new student();
        stu2.setName("����");
        stu2.setAge(19);
        stu2.setGender("Ů");
        System.out.println(stu2.getName());
        System.out.println(stu2.getAge());
        System.out.println(stu2.getGender());

        stu2.sleep();
        stu2.study();
    }
}
