package arrTest3;

import java.util.Scanner;

public class PhoneTest {
    public static void main(String[] args) {
        Phone[] arr = new Phone[3];
        Scanner sc = new Scanner(System.in);
        double sum = 0;

        for (int i = 0; i < arr.length; i++) {
            Phone phone = new Phone();

            System.out.println("�������ֻ���Ʒ��");
            String brand = sc.next();
            phone.setBrand(brand);
            System.out.println("�������ֻ��ļ۸�");
            double price = sc.nextDouble();
            phone.setPrice(price);
            sum += price;
            System.out.println("�������ֻ�����ɫ");
            String color = sc.next();
            phone.setColor(color);

            arr[i] = phone;
        }

        System.out.println(sum / 3);
    }
}
