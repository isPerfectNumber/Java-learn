package demo_this;

public class StudentTest {
    public static void main(String[] args) {
        Student stu1 = new Student();

        stu1.method();
    }
}
