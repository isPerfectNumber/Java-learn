package phone;

public class phone {
    //����
    String brand;
    double price;

    //��Ϊ
    public void call(){
        System.out.println("��绰");
    }
    public void playGame(){
        System.out.println("����Ϸ");
    }
}
