package oop_03_abstract.demo1;

public class test {
    public static void main(String[] args) {
        Dog d = new Dog("���", 3);
        System.out.println(d.getName() + "," + d.getAge());
        d.eat();
        d.drink();
    }
}
