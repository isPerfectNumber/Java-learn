package oop_01_inheritance.demo4;

public class test {
    public static void main(String[] args) {
        Manager m = new Manager("00001", "zhangsan", 15000, 8000);
        System.out.println(m.getId() + "," + m.getName() + "," + m.getSalary() + "," + m.getSalary());
        m.work();
        m.eat();

        Cook c = new Cook();
        c.setId("00002");
        c.setName("lisi");
        c.setSalary(8000);
        System.out.println(c.getId() + "," + c.getName() + "," + c.getSalary() + "," + c.getSalary());
        c.work();
        c.eat();
    }
}
