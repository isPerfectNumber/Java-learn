package oop_01_inheritance.demo4;

public class Cook extends Employee{

    public Cook() {
    }

    public Cook(String id, String name, double salary) {
        super(id, name, salary);
    }

    @Override
    public void work(){
        System.out.println("��ʦ�ڳ���");
    }
}
