package oop_01_inheritance.demo3;

public class Person {
    String name;
    int age;

    public Person() {
        System.out.println("������޲ι���");
    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}
