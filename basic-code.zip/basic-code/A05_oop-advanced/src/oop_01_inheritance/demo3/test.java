package oop_01_inheritance.demo3;

public class test {
    public static void main(String[] args) {
        //����ѧ������
        Student s = new Student("zhangsan", 23);
        System.out.println(s.name + "," + s.age);
    }
}
