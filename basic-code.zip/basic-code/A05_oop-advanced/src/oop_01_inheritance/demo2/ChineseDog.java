package oop_01_inheritance.demo2;

public class ChineseDog extends Dog{
    @Override
    public void eat(){
        System.out.println("�л���԰Ȯ�ڳ�ʣ��");
    }
}
