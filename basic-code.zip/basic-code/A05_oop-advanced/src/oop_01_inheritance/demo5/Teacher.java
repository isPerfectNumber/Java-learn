package oop_01_inheritance.demo5;

public class Teacher extends Employee{
    public Teacher() {
    }

    public Teacher(String id, String name) {
        super(id, name);
    }

    @Override
    public void work(){
        System.out.println("��ѧ");
    }
}
