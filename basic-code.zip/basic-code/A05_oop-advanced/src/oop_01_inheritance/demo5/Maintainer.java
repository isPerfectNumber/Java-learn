package oop_01_inheritance.demo5;

public class Maintainer extends AdminStaff{
    public Maintainer() {
    }

    public Maintainer(String id, String name) {
        super(id, name);
    }

    @Override
    public void work(){
        System.out.println("����ά���豸");
    }
}
