package oop_01_inheritance.demo5;

public class test {
    public static void main(String[] args) {
        Teacher t = new Teacher("001", "����");
        System.out.println(t.getId() + "," + t.getName());
        t.work();

        Maintainer mt = new Maintainer("002", "����");
        System.out.println(mt.getId() + "," + mt.getName());
        mt.work();

        Buyer b = new Buyer("003", "����");
        System.out.println(b.getId() + "," + b.getName());
        b.work();
    }
}
