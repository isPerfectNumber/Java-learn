package oop_01_inheritance.demo1;

public class Husky extends Dog {

    public void breakHome() {
        System.out.println("��ʿ���ڲ��");
    }
}
