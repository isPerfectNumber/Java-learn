package oop_01_inheritance.demo1;

public class Cat extends Animal{
    public void catchMouse(){
        System.out.println("è��ץ����");
    }
}
