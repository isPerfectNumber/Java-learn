package oop_01_inheritance.demo1;

public class Dog extends Animal{
    public void lookHome(){
        System.out.println("������");
    }
}
