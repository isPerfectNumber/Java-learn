package oop_01_inheritance.demo1;

public class LiHua extends Cat{

}
