package oop_05_innerclass.demo2;

public class test {
    public static void main(String[] args) {
        Outer o = new Outer();
        Object inner = o.getInstance();//Inner���ֱ�Ӹ�����Object��
        System.out.println(inner);
    }
}
