package oop_05_innerclass.demo3;

public class Outer {
//    int a = 10;
//    static int b = 20;

    static class Inner{
        public void show1(){
            System.out.println("�Ǿ�̬����������");
//            Outer o = new Outer();
//            System.out.println(o.a);
//            System.out.println(b);
        }

        public static void show2(){
            System.out.println("��̬����������");
//            Outer o = new Outer();
//            System.out.println(o.a);
//            System.out.println(b);
        }
    }
}
