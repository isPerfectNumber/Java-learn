package oop_05_innerclass.demo4;

public interface Swim {
    public abstract void swim();
}
