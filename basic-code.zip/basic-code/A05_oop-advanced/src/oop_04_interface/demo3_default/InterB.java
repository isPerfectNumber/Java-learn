package oop_04_interface.demo3_default;

public interface InterB {
    public default void show(){
        System.out.println("default method B");
    }
}
