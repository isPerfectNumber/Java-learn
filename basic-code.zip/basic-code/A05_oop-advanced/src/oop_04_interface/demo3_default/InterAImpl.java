package oop_04_interface.demo3_default;

public class InterAImpl implements InterA,InterB{

    @Override
    public void method() {
        System.out.println("abstract method");
    }

    @Override
    public void show() {
        System.out.println("override default method");
    }
}
