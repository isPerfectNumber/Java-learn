package oop_04_interface.demo3_default;

public class test {
    public static void main(String[] args) {
        //����ʵ����Ķ���
        InterAImpl ii = new InterAImpl();
        ii.method();
        ii.show();
    }
}
