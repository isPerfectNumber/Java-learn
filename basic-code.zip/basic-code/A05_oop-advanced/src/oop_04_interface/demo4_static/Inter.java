package oop_04_interface.demo4_static;

public interface Inter {
    public abstract void method();

    public static void show(){
        System.out.println("static method");
    }
}
