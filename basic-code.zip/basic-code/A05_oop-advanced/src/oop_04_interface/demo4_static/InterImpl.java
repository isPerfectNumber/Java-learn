package oop_04_interface.demo4_static;

public class InterImpl implements Inter{

    @Override
    public void method() {
        System.out.println("override abstract method");
    }

    public static void show(){
        System.out.println("static method from Inter?");
    }
}
