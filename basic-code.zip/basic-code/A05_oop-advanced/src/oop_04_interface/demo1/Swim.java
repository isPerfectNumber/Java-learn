package oop_04_interface.demo1;

public interface Swim {
    public abstract void swim();
}
