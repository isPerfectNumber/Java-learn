package oop_04_interface.demo1;

public class test {
    public static void main(String[] args) {
        Frog f = new Frog("С��", 1);
        System.out.println(f.getName() + "," + f.getAge());
        f.eat();
        f.swim();

        Rabbit r = new Rabbit("С��", 2);
        System.out.println(r.getName() + "," + r.getAge());
        r.eat();


    }
}
