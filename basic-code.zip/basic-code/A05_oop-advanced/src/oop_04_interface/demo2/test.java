package oop_04_interface.demo2;

public class test {
    public static void main(String[] args) {
        TableTennisPlayer ttp = new TableTennisPlayer("��ʫ��", 23);
        System.out.println(ttp.getName() + "," + ttp.getAge());
        ttp.study();
        ttp.SpeakEnglish();
    }
}
