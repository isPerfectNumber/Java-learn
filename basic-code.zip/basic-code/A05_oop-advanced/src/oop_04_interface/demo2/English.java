package oop_04_interface.demo2;

public interface English {
    void SpeakEnglish();
}
