package oop_04_interface.demo2;

public class TableTennisPlayer extends Players implements English{
    public TableTennisPlayer() {
    }

    public TableTennisPlayer(String name, int age) {
        super(name, age);
    }

    @Override
    public void study() {
        System.out.println("ѧ��ƹ����");
    }


    @Override
    public void SpeakEnglish() {
        System.out.println("˵Ӣ��");
    }
}
