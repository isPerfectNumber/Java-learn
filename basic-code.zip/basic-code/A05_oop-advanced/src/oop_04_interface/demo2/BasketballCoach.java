package oop_04_interface.demo2;

public class BasketballCoach extends Coaches{
    public BasketballCoach() {
    }

    public BasketballCoach(String name, int age) {
        super(name, age);
    }

    @Override
    public void teach() {
        System.out.println("�̴�����");
    }

}
