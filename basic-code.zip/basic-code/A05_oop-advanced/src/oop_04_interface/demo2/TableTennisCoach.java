package oop_04_interface.demo2;

public class TableTennisCoach extends Coaches implements English{
    public TableTennisCoach() {
    }

    public TableTennisCoach(String name, int age) {
        super(name, age);
    }

    @Override
    public void teach() {
        System.out.println("�̴�ƹ����");
    }

    @Override
    public void SpeakEnglish() {
        System.out.println("˵Ӣ��");
    }
}
