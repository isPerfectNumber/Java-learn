package oop_04_interface.demo2;

public class BasketballPlayer extends Players{
    public BasketballPlayer() {
    }

    public BasketballPlayer(String name, int age) {
        super(name, age);
    }

    @Override
    public void study() {
        System.out.println("ѧ������");
    }

}
