package oop_02_polymorphism.demo1;

public class Administrator extends Person{

    @Override
    public void show(){
        System.out.println("����Ա����ϢΪ��"+getName()+","+getAge());
    }
}
