package oop_02_polymorphism.demo1;

public class Teacher extends Person {

    @Override
    public void show() {
        System.out.println("��ʦ����ϢΪ��" + getName() + "," + getAge());
    }
}
