package oop_02_polymorphism.demo2;

public class Cat extends Animal {

    public Cat() {
    }

    public Cat(int age, String color) {
        super(age, color);
    }

    @Override
    public void eat(String sth) {
        System.out.println("�����۾�����ͷ��" + sth);
    }

    public void catchMouse() {
        System.out.println("èץ����");
    }
}
