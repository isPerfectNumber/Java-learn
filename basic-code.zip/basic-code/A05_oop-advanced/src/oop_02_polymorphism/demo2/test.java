package oop_02_polymorphism.demo2;

public class test {
    public static void main(String[] args) {
        Person p1 = new Person("����", 30);
        Dog d = new Dog(2, "��");

//        p1.keepPet(d, "��ͷ");
        p1.keepPet(d, "��ͷ");

        Person p2 = new Person("����", 25);
        Cat c = new Cat(3, "��");

//        p2.keepPet(c, "��");
        p2.keepPet(c, "��");

    }
}
