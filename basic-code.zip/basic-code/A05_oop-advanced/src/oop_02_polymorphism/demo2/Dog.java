package oop_02_polymorphism.demo2;

public class Dog extends Animal {

    public Dog() {
    }

    public Dog(int age, String color) {
        super(age, color);
    }

    @Override
    public void eat(String sth) {
        System.out.println("��ֻǰ��������ס" + sth + "�ͳ�");
    }

    public void lookHome() {
        System.out.println("������");
    }
}
