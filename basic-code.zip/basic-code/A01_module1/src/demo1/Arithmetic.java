package demo1;

public class Arithmetic {
    public static void main(String[] args) {
        System.out.println(1.1+1.01);
        System.out.println(1.1*1.1);
        System.out.println(8.0/3);
        byte a = 10;
        byte b = 20;
        byte result = (byte)(a+b);
        System.out.println(result);
        int c = 10;
        int i;
        i = c++;
        System.out.println(i);
        i = ++c;
        System.out.println(i);
    }
}
