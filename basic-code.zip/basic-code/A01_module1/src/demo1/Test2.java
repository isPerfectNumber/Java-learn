package demo1;

import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("input a here:");
        int a = sc.nextInt();
        System.out.println("input b here:");
        int b = sc.nextInt();
        System.out.println(a>b);
    }
}
