package demo1;

public class Array {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4, 5};
        System.out.println(arr1);//[I@27bc2616
        int[] arr2 = new int[5];
        String[] arr3 = new String[5];
        System.out.println(arr2[0]);
        System.out.println(arr3[0]);
    }
}
