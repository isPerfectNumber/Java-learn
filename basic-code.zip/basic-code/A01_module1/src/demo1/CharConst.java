package demo1;

public class CharConst {
    public static void main(String[] args) {
        char c1 = 'Q';
        char c2 = '\u0051';
        char c3 = 0x0051;
        System.out.println(c1+";"+c2+";"+c3+";"+'\121');
    }
}
