package demo1;

import java.util.Scanner;

public class Test3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("input a here:");
        int a = sc.nextInt();
        System.out.println("input b here:");
        int b = sc.nextInt();
        System.out.println(a==6 || b==6);
        System.out.println((a+b)%6==0);
        System.out.println(Math.max(a, b));
        System.out.println("input c here:");
        int c = sc.nextInt();
        int d = Math.max(a, b);
        System.out.println(Math.max(c, d));
        System.out.println((int)Math.pow(2, 3));
    }
}
