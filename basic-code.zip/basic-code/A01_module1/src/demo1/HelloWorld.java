package demo1;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("HelloWorld!");
        System.out.println("�������");
    }
}
