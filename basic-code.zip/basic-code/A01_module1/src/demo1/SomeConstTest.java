package demo1;

public class SomeConstTest {
    public static void main(String[] args) {
        int x,y;                    //声明整型变量
        float z = 3.414f;           //声明并赋值float型变量
        double w = 3.1415;          //声明并赋值double型变量
        boolean truth = true;       //声明并赋值boolean型变量
        char c;                     //声明字符变量
        String str;                 //声明String型变量
        String str1 = "bye";        //声明并赋值String型变量
        x = 6;
        y = 1000;
        c = 'A';
        str = "Hi out there";
    }
}
