package demo2;

import java.util.Scanner;

public class ticket2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("input the original price");
        double ticket = sc.nextInt();
        System.out.println("input the month");
        int month = sc.nextInt();
        System.out.println("input the option: 0 for first class, 1 for economy class");
        int seat = sc.nextInt();
        if(month >=5 && month <= 10){
            ticket = getTicket(ticket, seat, 0.9, 0.85);
        }
        else if((month >=1 && month <=4)||(month >=11 && month <=12)){
            //ticket = getPrice(ticket, seat, 0.7, 0.65);
            ticket = getTicket(ticket, seat, 0.7, 0.65);
        }
        else System.out.println("no such month");

        System.out.println(ticket);
    }

    public static double getTicket(double ticket, int seat, double v1, double v2) {
        //ticket = getPrice(ticket, seat, 0.9, 0.85);
        if(seat ==0) ticket *= v1;
        else if(seat ==1) ticket *= v2;
        else System.out.println("no such option");
        return ticket;
    }
}
