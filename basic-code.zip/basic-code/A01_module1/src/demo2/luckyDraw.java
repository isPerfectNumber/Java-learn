package demo2;

import java.util.Random;

public class luckyDraw {
    public static void main(String[] args) {
        //���������ʾ����
        int[] arr = {2, 588, 888, 1000, 10000};
        //����������洢�齱���
        int[] newArr = new int[arr.length];
        //�齱
        Random r = new Random();
        for (int i = 0; i < 5; ) {
            int randomIndex = r.nextInt(arr.length);
            int prize = arr[randomIndex];
            if(!contains(newArr, prize)){//��ȡ����Ч����
                newArr[i] = prize;
                i++;
            }
        }
        for (int i = 0; i < newArr.length; i++) {
            System.out.println(newArr[i]);
        }
    }

    public static boolean contains(int[] arr, int prize){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] == prize){
                return true;//��Ч
            }
        }
        return false;//��Ч
    }
}
