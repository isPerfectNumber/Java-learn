package demo2;

import java.util.Scanner;

public class ticket {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("please input the original price");
        double price = sc.nextInt();
        System.out.println("please input the month");
        int month = sc.nextInt();
        System.out.println("please select the seat");
        System.out.println("0 for First Class Seat, 1 for Economy Class Seat");
        int option = sc.nextInt();
        price = price * getDiscount(month, option);
        System.out.println("the price is:");
        System.out.print(price);
    }

    public static double getDiscount(int month, int option){
        double discount = 0;
        if(month>=5 && month<=10){
            if(option == 1) discount = 0.9;
            else if (option == 0) discount = 0.85;
        } else if ((month>=11 && month<=12)||(month>=1 && month<=4)) {
            if(option == 1) discount = 0.7;
            else if(option == 0) discount = 0.65;
        }
        return discount;
    }
}
