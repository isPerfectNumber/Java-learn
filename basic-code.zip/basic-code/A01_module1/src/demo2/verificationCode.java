package demo2;

import java.util.Random;

public class verificationCode {
    public static void main(String[] args) {
        /* 随机产生一个五位验证码，前四位为随机大小写字母，最后一位是数字 */

        //方法：
        //如果要在一堆没有规律的数据中随机抽取，
        //可以先把这些数据放到数组中再随机抽取一个索引

        //分析：
        //1.大写字母和小写字母都放到数组中
        char[] chs = new char[52];
        for (int i = 0; i < chs.length; i++) {
            if (i <= 25) {
                //添加小写字母
                chs[i] = (char) (97 + i);
            } else {
                //添加大写字母
                chs[i] = (char) (65 + i - 26);
            }
        }
        //遍历
//        for (int i = 0; i < chs.length; i++) {
//            System.out.print(chs[i] + " ");
//        }

        //定义一个字符串用于记录最终的结果
        String result = "";

        //2.随机抽取4次
        Random r = new Random();
        //随机抽取数组索引
        for (int i = 0; i < 4; i++) {
            int randomIndex = r.nextInt(chs.length);
            //利用随机索引获取对应元素
            //System.out.println(chs[randomIndex]);
            result += (chs[randomIndex]);
        }
        //System.out.println(result);

        //3.随机抽取一个数字0-9
        int number = r.nextInt(10);
        //生成最终结果
        result += number;
        //打印最终结果
        System.out.println(result);
    }
}
