package demo;

import java.util.ArrayList;

public class demo2 {
    public static void main(String[] args) {
        //1.����һ������
        ArrayList<String> list = new ArrayList<>();

        //2.����Ԫ��
        boolean result1 = list.add("aaa");
        System.out.println(result1);//true
        System.out.println(list);//[aaa]
        list.add("bbb");
        list.add("ccc");
        System.out.println(list);//[aaa, bbb, ccc]

        //3.ɾ��Ԫ��
        boolean result2 = list.remove("aaa");
        System.out.println(result2);//true
        System.out.println(list);//[bbb, ccc]
        boolean result3 = list.remove("ddd");
        System.out.println(result3);//false
        //list = [bbb, ccc]
        String str = list.remove(0);
        System.out.println(str);//bbb

        list.add("aaa");
        list.add("bbb");
        System.out.println(list);//[ccc, aaa, bbb]

        //4.�޸�Ԫ��
        String result4 = list.set(1, "ddd");//aaa -> ddd
        System.out.println(result4);//aaa
        System.out.println(list);//[ccc, ddd, bbb]

        //5.��������������ѯԪ��
        String s = list.get(0);
        System.out.println(s);//ccc

        //����
        for (int i = 0; i < list.size(); i++) {
            //i ����
            //list.get(i) Ԫ��
            String str2 = list.get(i);
            System.out.println(str2);
        }
    }
}
