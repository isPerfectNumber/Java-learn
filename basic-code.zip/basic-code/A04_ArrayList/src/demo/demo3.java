package demo;

import java.util.ArrayList;
import java.util.StringJoiner;

public class demo3 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();

        list.add("aaa");
        list.add("bbb");
        list.add("ccc");

        StringJoiner sj = new StringJoiner(",", "[", "]");
        for (int i = 0; i < list.size(); i++) {
            sj.add(list.get(i));
        }
        System.out.println(sj);
    }
}
