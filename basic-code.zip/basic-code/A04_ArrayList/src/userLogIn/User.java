package userLogIn;

public class User {
    private String name;
    private String password;
    private String phone;
    private String idNum;
    private boolean nameSet;
    private boolean phoneSet;
    private boolean idNumSet;

    public User() {
    }

    public User(String name, String password, String phone, String idNum) {
        this.name = name;
        this.password = password;
        this.phone = phone;
        this.idNum = idNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (checkLength(name, 3, 15)) {
            int flag = 0;
            for (int i = 0; i < name.length(); i++) {
                if (!((name.charAt(i) >= '0' && name.charAt(i) <= '9') || (name.charAt(i) >= 'A' && name.charAt(i) <= 'Z') || (name.charAt(i) >= 'a' && name.charAt(i) <= 'z'))) {
                    System.out.println("�û��������Ϲ淶�����������룡");
                    flag = 0;
                    break;
                }
                if ((name.charAt(i) >= 'a' && name.charAt(i) <= 'z') || (name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {
                    flag = 1;
                }
            }
            if (flag == 1) {
                this.name = name;
                nameSet = true;
            }
        } else {
            System.out.println("�û������ȷǷ������������룡");
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (checkLength(phone, 11) && (phone.charAt(0) != '0')) {
            int flag = 0;
            for (int i = 0; i < phone.length(); i++) {
                if (!(phone.charAt(i) >= '0' && phone.charAt(i) <= '9')) {
                    System.out.println("�ֻ������ʽ�������������룡");
                    flag = 0;
                    break;
                }
                flag = 1;
            }
            if (flag == 1) {
                this.phone = phone;
                phoneSet = true;
            }
        } else {
            System.out.println("�ֻ������ʽ�������������룡");
        }
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        if (checkLength(idNum, 18) && (idNum.charAt(0) != '0')) {
            int flag = 0;
            for (int i = 0; i < idNum.length() - 1; i++) {
                if (!(idNum.charAt(i) >= '0' && idNum.charAt(i) <= '9')) {
                    System.out.println("����֤�Ÿ�ʽ�������������룡");
                    flag = 0;
                    break;
                }
                flag = 1;
            }
            if (flag == 1) {
                if (idNum.charAt(17) == 'x' || idNum.charAt(17) == 'X' || (idNum.charAt(17) >= '0' && idNum.charAt(17) <= '9')) {
                    this.idNum = idNum;
                    idNumSet = true;
                } else {
                    System.out.println("����֤�Ÿ�ʽ�������������룡");
                }
            }
        } else {
            System.out.println("����֤�Ÿ�ʽ�������������룡");
        }
    }

    public boolean isNameSet() {
        return nameSet;
    }

    public void setNameSet(boolean nameSet) {
        this.nameSet = nameSet;
    }

    public boolean isPhoneSet() {
        return phoneSet;
    }

    public void setPhoneSet(boolean phoneSet) {
        this.phoneSet = phoneSet;
    }

    public boolean isIdNumSet() {
        return idNumSet;
    }

    public void setIdNumSet(boolean idNumSet) {
        this.idNumSet = idNumSet;
    }

    //��������
    public boolean checkLength(String str, int len) {
        return (str.length() == len);
    }

    public boolean checkLength(String str, int len1, int len2) {
        return (str.length() >= Math.min(len1, len2) && str.length() <= Math.max(len1, len2));
    }
}
