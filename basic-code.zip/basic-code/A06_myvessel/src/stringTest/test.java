package stringTest;

public class test {
    public static void main(String[] args) {
        String str1 = "I love banana";
        String str2 = "na";
        System.out.println(str1.indexOf(str2));
    }
}
